export interface Contact {
  id: string;
  name: string;
  phone: string;
  relation: string;
}

export interface MedicalProfile {
  fullName: string;
  dob: string;
  bloodGroup: string;
  allergies: string;
  medications: string;
  conditions: string;
  organDonor: boolean;
  notes: string;
}

export interface AlertEvent {
  id: string;
  type: "sos" | "safe" | "checkin";
  timestamp: number;
  lat?: number;
  lng?: number;
  accuracy?: number;
}

export const emptyMedicalProfile: MedicalProfile = {
  fullName: "",
  dob: "",
  bloodGroup: "",
  allergies: "",
  medications: "",
  conditions: "",
  organDonor: false,
  notes: "",
};