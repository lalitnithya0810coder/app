/**
 * Web Audio panic siren — a sweeping two-tone alarm. No assets required.
 */
let ctx: AudioContext | null = null;
let osc: OscillatorNode | null = null;
let gain: GainNode | null = null;
let lfoTimer: number | null = null;

export function startSiren() {
  if (typeof window === "undefined") return;
  if (osc) return;
  const AC =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext })
      .webkitAudioContext;
  ctx = ctx ?? new AC();
  if (ctx.state === "suspended") void ctx.resume();

  osc = ctx.createOscillator();
  gain = ctx.createGain();
  osc.type = "sawtooth";
  gain.gain.value = 0.0001;
  gain.gain.exponentialRampToValueAtTime(0.4, ctx.currentTime + 0.05);
  osc.connect(gain).connect(ctx.destination);
  osc.start();

  let high = true;
  const sweep = () => {
    if (!osc || !ctx) return;
    const target = high ? 1000 : 600;
    osc.frequency.setTargetAtTime(target, ctx.currentTime, 0.12);
    high = !high;
  };
  sweep();
  lfoTimer = window.setInterval(sweep, 450);
}

export function stopSiren() {
  if (lfoTimer) {
    window.clearInterval(lfoTimer);
    lfoTimer = null;
  }
  if (gain && ctx) {
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.08);
  }
  if (osc) {
    const o = osc;
    osc = null;
    setTimeout(() => {
      try {
        o.stop();
        o.disconnect();
      } catch {
        /* ignore */
      }
    }, 120);
  }
}