export interface ServiceNumber {
  label: string;
  number: string;
  icon: string;
}

export const emergencyServices: ServiceNumber[] = [
  { label: "Emergency (All)", number: "112", icon: "siren" },
  { label: "Police", number: "911", icon: "shield" },
  { label: "Ambulance", number: "911", icon: "ambulance" },
  { label: "Fire Department", number: "911", icon: "flame" },
  { label: "Poison Control", number: "1-800-222-1222", icon: "skull" },
  { label: "Suicide & Crisis", number: "988", icon: "heart-pulse" },
  { label: "Child Welfare Hotline", number: "1-800-422-4453", icon: "baby" },
  { label: "Domestic Violence Hotline", number: "1-800-799-7233", icon: "shield-user" },
  { label: "Human Trafficking Hotline", number: "1-888-373-7888", icon: "alert-triangle" },
  { label: "Missing & Exploited Children", number: "1-800-843-5678", icon: "search" },
  { label: "Substance Abuse & Mental Health", number: "1-800-662-4357", icon: "pill" },
  { label: "FEMA Disaster Assistance", number: "1-800-621-3362", icon: "cloud-lightning" },
];

export interface HelpCenter {
  name: string;
  type: "Hospital" | "Police" | "Shelter" | "Pharmacy";
  detail: string;
}

export const nearbyHelpCenters: HelpCenter[] = [
  { name: "City General Hospital", type: "Hospital", detail: "24/7 emergency room & trauma center" },
  { name: "Central Police Station", type: "Police", detail: "Round-the-clock response unit" },
  { name: "Riverside Medical Center", type: "Hospital", detail: "Cardiac & stroke unit" },
  { name: "Safe Haven Shelter", type: "Shelter", detail: "Emergency shelter & support services" },
  { name: "MedPlus 24hr Pharmacy", type: "Pharmacy", detail: "Open 24 hours · first aid supplies" },
  { name: "Northgate Police Outpost", type: "Police", detail: "Neighborhood patrol & assistance" },
];

export interface FirstAidGuide {
  id: string;
  title: string;
  summary: string;
  steps: string[];
}

export const firstAidGuides: FirstAidGuide[] = [
  {
    id: "cpr",
    title: "CPR (Adult)",
    summary: "When someone is unresponsive and not breathing normally.",
    steps: [
      "Check responsiveness and call emergency services immediately.",
      "Place the heel of your hand on the center of the chest.",
      "Push hard and fast: 100–120 compressions per minute, ~5cm deep.",
      "Give 30 compressions, then 2 rescue breaths if trained.",
      "Continue until help arrives or the person revives.",
    ],
  },
  {
    id: "choking",
    title: "Choking",
    summary: "Person cannot breathe, speak, or cough.",
    steps: [
      "Encourage them to cough forcefully if possible.",
      "Give 5 firm back blows between the shoulder blades.",
      "Give 5 abdominal thrusts (Heimlich maneuver).",
      "Alternate 5 back blows and 5 thrusts until cleared.",
      "If they become unresponsive, start CPR and call for help.",
    ],
  },
  {
    id: "bleeding",
    title: "Severe Bleeding",
    summary: "Heavy bleeding from a wound.",
    steps: [
      "Apply firm, direct pressure with a clean cloth.",
      "Keep pressure on; add layers, don't remove soaked cloth.",
      "Raise the injured area above heart level if possible.",
      "Secure with a bandage and keep the person warm.",
      "Call emergency services if bleeding won't stop.",
    ],
  },
  {
    id: "burns",
    title: "Burns",
    summary: "Thermal or scald burns.",
    steps: [
      "Cool the burn under cool running water for 20 minutes.",
      "Remove jewelry/clothing near the burn (not if stuck).",
      "Cover loosely with cling film or a clean non-fluffy cloth.",
      "Do not apply ice, butter, or creams.",
      "Seek medical help for large or deep burns.",
    ],
  },
  {
    id: "seizure",
    title: "Seizure",
    summary: "Sudden uncontrolled convulsions.",
    steps: [
      "Stay calm and clear the area of hard objects.",
      "Cushion their head and loosen tight clothing.",
      "Do not restrain them or put anything in their mouth.",
      "Time the seizure; turn them on their side after it stops.",
      "Call for help if it lasts over 5 minutes or repeats.",
    ],
  },
  {
    id: "stroke",
    title: "Stroke (FAST)",
    summary: "Recognize stroke signs quickly.",
    steps: [
      "Face: ask them to smile — is one side drooping?",
      "Arms: can they raise both arms and keep them up?",
      "Speech: is speech slurred or strange?",
      "Time: if any sign is present, call emergency services now.",
      "Note the time symptoms started for responders.",
    ],
  },
  {
    id: "anaphylaxis",
    title: "Severe Allergic Reaction",
    summary: "Life-threatening allergy to food, stings, or medication.",
    steps: [
      "Call emergency services immediately.",
      "Use an epinephrine auto-injector if available — inject into the outer thigh.",
      "Lay the person flat and keep them calm and still.",
      "If they vomit or have trouble breathing, lay them on their side.",
      "Give a second epinephrine shot after 5–15 minutes if symptoms persist.",
    ],
  },
  {
    id: "asthma",
    title: "Asthma Attack",
    summary: "Sudden shortness of breath, wheezing, or chest tightness.",
    steps: [
      "Help the person sit upright and stay calm.",
      "Loosen tight clothing and move them away from smoke or triggers.",
      "Use the reliever inhaler: 1 puff with a spacer, repeat up to 4 times.",
      "Call emergency services if no relief after 4 puffs or symptoms worsen.",
      "Stay with them until help arrives; be ready to start CPR if they collapse.",
    ],
  },
  {
    id: "heatstroke",
    title: "Heat Stroke",
    summary: "High body temperature with confusion or unconsciousness.",
    steps: [
      "Call emergency services — heat stroke is a medical emergency.",
      "Move the person to a cool, shaded place and remove excess clothing.",
      "Cool the body with water, wet cloths, or ice packs on the neck and armpits.",
      "Fan them while applying cool water to the skin.",
      "Do not give medication or fluids if they are unconscious or vomiting.",
    ],
  },
  {
    id: "hypothermia",
    title: "Hypothermia",
    summary: "Dangerously low body temperature from cold exposure.",
    steps: [
      "Move the person to a warm, dry shelter and remove wet clothing.",
      "Wrap them in dry blankets, including their head and neck.",
      "Give warm (not hot) non-alcoholic drinks if fully conscious.",
      "Use skin-to-skin contact or warm compresses on the chest and groin.",
      "Call emergency services if shivering stops, breathing slows, or confusion occurs.",
    ],
  },
  {
    id: "nosebleed",
    title: "Nosebleed",
    summary: "Bleeding from the nose, usually from the front of the septum.",
    steps: [
      "Sit upright and lean slightly forward — do not tilt the head back.",
      "Pinch the soft part of the nose firmly for 10–15 minutes.",
      "Breathe through the mouth and avoid swallowing blood.",
      "Apply a cold compress to the bridge of the nose and cheeks.",
      "Seek medical help if bleeding continues after 20 minutes or is heavy.",
    ],
  },
  {
    id: "fracture",
    title: "Fractures & Sprains",
    summary: "Broken or badly sprained limbs.",
    steps: [
      "Encourage the person to keep still and support the injured area.",
      "For open fractures, cover the wound with a clean dressing without pushing bone back.",
      "Apply a splint using a rigid object and soft padding to immobilize the limb.",
      "Elevate the limb if possible and apply a cold pack to reduce swelling.",
      "Call emergency services for severe deformity, open fracture, or numbness.",
    ],
  },
  {
    id: "poisoning",
    title: "Poisoning",
    summary: "Swallowed, inhaled, or absorbed a harmful substance.",
    steps: [
      "Call Poison Control or emergency services immediately.",
      "Do not induce vomiting unless told to do so by a professional.",
      "If the substance is on the skin, remove contaminated clothing and rinse with water.",
      "If inhaled, move the person to fresh air and loosen tight clothing.",
      "Keep the container or label to show responders what was taken.",
    ],
  },
  {
    id: "diabetic",
    title: "Diabetic Emergency",
    summary: "Low or high blood sugar causing confusion or unconsciousness.",
    steps: [
      "If awake and sweaty/shaky, give 15g fast sugar: glucose tablets, juice, or sweets.",
      "If unconscious, do not give food or drink — place them in recovery position.",
      "Call emergency services if they do not improve within 15 minutes.",
      "If they have a glucagon kit and are trained, administer it for severe lows.",
      "Stay with them, monitor breathing, and be ready to start CPR if needed.",
    ],
  },
  {
    id: "eyeinjury",
    title: "Eye Injury",
    summary: "Chemicals, particles, or trauma affecting the eye.",
    steps: [
      "For chemicals, flush the eye with clean water for at least 15 minutes.",
      "Do not rub the eye or try to remove embedded objects.",
      "Cover the injured eye with a clean, loose dressing or eye shield.",
      "Seek emergency care immediately for chemical burns or penetrating injuries.",
      "If a contact lens is in the eye, do not remove it during chemical flushing.",
    ],
  },
  {
    id: "fainting",
    title: "Fainting",
    summary: "Brief loss of consciousness due to reduced blood flow to the brain.",
    steps: [
      "Lay the person flat on their back and elevate their legs.",
      "Loosen tight clothing and ensure fresh air.",
      "Check breathing and pulse; call emergency services if not responsive.",
      "Once awake, give small sips of water and let them rest.",
      "Do not let them get up quickly; help them sit up gradually.",
    ],
  },
];