import type { Contact } from "./types";

/**
 * Build a platform-correct `sms:` deep link. This hands off to the device's
 * native Messaging app, which sends over the cellular network — so it works
 * even with no internet connection.
 *
 * iOS expects `&body=`, while Android/most others expect `?body=`.
 */
export function buildSmsLink(numbers: string[], body: string) {
  const recipients = numbers
    .map((n) => n.replace(/[^\d+]/g, ""))
    .filter(Boolean)
    .join(",");
  const isIOS =
    typeof navigator !== "undefined" &&
    /iPad|iPhone|iPod/.test(navigator.userAgent);
  const separator = isIOS ? "&" : "?";
  return `sms:${recipients}${separator}body=${encodeURIComponent(body)}`;
}

export function buildSosMessage(opts: {
  name?: string;
  mapsUrl?: string;
}) {
  const who = opts.name?.trim() ? opts.name.trim() : "I";
  const lines = [
    `EMERGENCY! ${who} need help right now.`,
    opts.mapsUrl ? `My location: ${opts.mapsUrl}` : "Location unavailable.",
    "Sent via Guardian SOS.",
  ];
  return lines.join("\n");
}

/**
 * Opens the native SMS composer pre-filled with every emergency contact and
 * the SOS message. Returns false if there are no contacts to notify.
 */
export function sendSmsFallback(contacts: Contact[], message: string) {
  const numbers = contacts.map((c) => c.phone);
  if (numbers.length === 0) return false;
  if (typeof window === "undefined") return false;
  window.location.href = buildSmsLink(numbers, message);
  return true;
}