import { useEffect, useState } from "react";

export type PermissionName = "geolocation" | "notifications" | "camera" | "microphone";

export interface PermissionStatus {
  name: PermissionName;
  state: "granted" | "denied" | "prompt" | "unknown";
  error?: string;
}

const STORAGE_KEY = "guardian.permissions-ack";

interface StoredAck {
  cookie: boolean;
  permissions: boolean;
  answeredAt?: number;
}

export function getStoredAck(): StoredAck {
  if (typeof window === "undefined") return { cookie: false, permissions: false };
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as StoredAck) : { cookie: false, permissions: false };
  } catch {
    return { cookie: false, permissions: false };
  }
}

export function saveAck(update: Partial<StoredAck>) {
  if (typeof window === "undefined") return;
  const next = { ...getStoredAck(), ...update, answeredAt: Date.now() };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
}

export function usePermissions() {
  const [statuses, setStatuses] = useState<Record<PermissionName, PermissionStatus["state"]>>({
    geolocation: "prompt",
    notifications: "prompt",
    camera: "prompt",
    microphone: "prompt",
  });

  useEffect(() => {
    if (typeof navigator === "undefined" || !navigator.permissions) return;

    const map: Partial<Record<PermissionName, PermissionDescriptor | string>> = {
      geolocation: { name: "geolocation" },
      notifications: { name: "notifications" },
      camera: { name: "camera" },
      microphone: { name: "microphone" },
    };

    const controllers: AbortController[] = [];

    const check = async () => {
      const next = { ...statuses };
      for (const name of Object.keys(map) as PermissionName[]) {
        try {
          const status = await navigator.permissions.query(map[name]! as PermissionDescriptor);
          next[name] = status.state as PermissionStatus["state"];
          const c = new AbortController();
          controllers.push(c);
          status.addEventListener("change", () => {
            setStatuses((prev) => ({ ...prev, [name]: status.state as PermissionStatus["state"] }));
          }, { signal: c.signal });
        } catch {
          next[name] = "unknown";
        }
      }
      setStatuses(next);
    };

    void check();
    return () => controllers.forEach((c) => c.abort());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const request = async (name: PermissionName): Promise<PermissionStatus> => {
    try {
      if (name === "geolocation") {
        await new Promise<void>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(
            () => resolve(),
            (err) => reject(err),
            { enableHighAccuracy: true, timeout: 10000 },
          );
        });
        setStatuses((s) => ({ ...s, geolocation: "granted" }));
        return { name, state: "granted" };
      }
      if (name === "notifications") {
        const result = await Notification.requestPermission();
        setStatuses((s) => ({ ...s, notifications: result as PermissionStatus["state"] }));
        return { name, state: result as PermissionStatus["state"] };
      }
      if (name === "camera" || name === "microphone") {
        const constraints: MediaStreamConstraints = { [name]: true };
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        stream.getTracks().forEach((t) => t.stop());
        setStatuses((s) => ({ ...s, [name]: "granted" }));
        return { name, state: "granted" };
      }
      return { name, state: "unknown" };
    } catch (err) {
      const state: PermissionStatus["state"] = "denied";
      setStatuses((s) => ({ ...s, [name]: state }));
      return { name, state, error: err instanceof Error ? err.message : String(err) };
    }
  };

  return { statuses, request };
}
