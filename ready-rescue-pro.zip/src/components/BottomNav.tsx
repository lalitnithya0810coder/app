import { Link } from "@tanstack/react-router";
import { Home, Users, HeartPulse, BookOpen, MapPin } from "lucide-react";

const items = [
  { to: "/", label: "SOS", icon: Home },
  { to: "/contacts", label: "Contacts", icon: Users },
  { to: "/safety", label: "Safety", icon: MapPin },
  { to: "/medical", label: "Medical", icon: HeartPulse },
  { to: "/guides", label: "First Aid", icon: BookOpen },
] as const;

export function BottomNav() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-popover/95 backdrop-blur">
      <div className="mx-auto flex max-w-md items-stretch justify-around px-2 pb-[env(safe-area-inset-bottom)]">
        {items.map(({ to, label, icon: Icon }) => (
          <Link
            key={to}
            to={to}
            activeOptions={{ exact: to === "/" }}
            className="flex flex-1 flex-col items-center gap-1 py-2.5 text-muted-foreground transition-colors data-[status=active]:text-primary"
          >
            <Icon className="h-5 w-5" strokeWidth={2.2} />
            <span className="text-[10px] font-medium">{label}</span>
          </Link>
        ))}
      </div>
    </nav>
  );
}