import { X } from "lucide-react";

export function FlashlightOverlay({ onClose }: { onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-[100] flex items-start justify-end p-4"
      style={{ animation: "strobe 0.5s steps(1) infinite" }}
    >
      <button
        onClick={onClose}
        aria-label="Stop flashlight"
        className="rounded-full bg-black/70 p-3 text-white"
      >
        <X className="h-6 w-6" />
      </button>
    </div>
  );
}