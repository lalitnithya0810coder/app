import { useEffect, useMemo, useRef, useState } from "react";
import { Globe, Search, X, Check } from "lucide-react";

/** Languages supported by Google Translate (code + native/English name). */
const LANGUAGES: { code: string; name: string }[] = [
  { code: "en", name: "English" },
  { code: "af", name: "Afrikaans" },
  { code: "sq", name: "Albanian" },
  { code: "am", name: "Amharic" },
  { code: "ar", name: "Arabic — العربية" },
  { code: "hy", name: "Armenian" },
  { code: "az", name: "Azerbaijani" },
  { code: "eu", name: "Basque" },
  { code: "be", name: "Belarusian" },
  { code: "bn", name: "Bengali — বাংলা" },
  { code: "bs", name: "Bosnian" },
  { code: "bg", name: "Bulgarian" },
  { code: "ca", name: "Catalan" },
  { code: "ceb", name: "Cebuano" },
  { code: "ny", name: "Chichewa" },
  { code: "zh-CN", name: "Chinese (Simplified) — 简体中文" },
  { code: "zh-TW", name: "Chinese (Traditional) — 繁體中文" },
  { code: "co", name: "Corsican" },
  { code: "hr", name: "Croatian" },
  { code: "cs", name: "Czech" },
  { code: "da", name: "Danish" },
  { code: "nl", name: "Dutch" },
  { code: "eo", name: "Esperanto" },
  { code: "et", name: "Estonian" },
  { code: "tl", name: "Filipino" },
  { code: "fi", name: "Finnish" },
  { code: "fr", name: "French — Français" },
  { code: "fy", name: "Frisian" },
  { code: "gl", name: "Galician" },
  { code: "ka", name: "Georgian" },
  { code: "de", name: "German — Deutsch" },
  { code: "el", name: "Greek — Ελληνικά" },
  { code: "gu", name: "Gujarati — ગુજરાતી" },
  { code: "ht", name: "Haitian Creole" },
  { code: "ha", name: "Hausa" },
  { code: "haw", name: "Hawaiian" },
  { code: "iw", name: "Hebrew — עברית" },
  { code: "hi", name: "Hindi — हिन्दी" },
  { code: "hmn", name: "Hmong" },
  { code: "hu", name: "Hungarian" },
  { code: "is", name: "Icelandic" },
  { code: "ig", name: "Igbo" },
  { code: "id", name: "Indonesian" },
  { code: "ga", name: "Irish" },
  { code: "it", name: "Italian — Italiano" },
  { code: "ja", name: "Japanese — 日本語" },
  { code: "jw", name: "Javanese" },
  { code: "kn", name: "Kannada — ಕನ್ನಡ" },
  { code: "kk", name: "Kazakh" },
  { code: "km", name: "Khmer" },
  { code: "rw", name: "Kinyarwanda" },
  { code: "ko", name: "Korean — 한국어" },
  { code: "ku", name: "Kurdish (Kurmanji)" },
  { code: "ky", name: "Kyrgyz" },
  { code: "lo", name: "Lao" },
  { code: "la", name: "Latin" },
  { code: "lv", name: "Latvian" },
  { code: "lt", name: "Lithuanian" },
  { code: "lb", name: "Luxembourgish" },
  { code: "mk", name: "Macedonian" },
  { code: "mg", name: "Malagasy" },
  { code: "ms", name: "Malay" },
  { code: "ml", name: "Malayalam — മലയാളം" },
  { code: "mt", name: "Maltese" },
  { code: "mi", name: "Maori" },
  { code: "mr", name: "Marathi — मराठी" },
  { code: "mn", name: "Mongolian" },
  { code: "my", name: "Myanmar (Burmese)" },
  { code: "ne", name: "Nepali — नेपाली" },
  { code: "no", name: "Norwegian" },
  { code: "or", name: "Odia (Oriya)" },
  { code: "ps", name: "Pashto" },
  { code: "fa", name: "Persian — فارسی" },
  { code: "pl", name: "Polish" },
  { code: "pt", name: "Portuguese — Português" },
  { code: "pa", name: "Punjabi — ਪੰਜਾਬੀ" },
  { code: "ro", name: "Romanian" },
  { code: "ru", name: "Russian — Русский" },
  { code: "sm", name: "Samoan" },
  { code: "gd", name: "Scots Gaelic" },
  { code: "sr", name: "Serbian" },
  { code: "st", name: "Sesotho" },
  { code: "sn", name: "Shona" },
  { code: "sd", name: "Sindhi" },
  { code: "si", name: "Sinhala" },
  { code: "sk", name: "Slovak" },
  { code: "sl", name: "Slovenian" },
  { code: "so", name: "Somali" },
  { code: "es", name: "Spanish — Español" },
  { code: "su", name: "Sundanese" },
  { code: "sw", name: "Swahili" },
  { code: "sv", name: "Swedish" },
  { code: "tg", name: "Tajik" },
  { code: "ta", name: "Tamil — தமிழ்" },
  { code: "tt", name: "Tatar" },
  { code: "te", name: "Telugu — తెలుగు" },
  { code: "th", name: "Thai — ไทย" },
  { code: "tr", name: "Turkish — Türkçe" },
  { code: "tk", name: "Turkmen" },
  { code: "uk", name: "Ukrainian — Українська" },
  { code: "ur", name: "Urdu — اردو" },
  { code: "ug", name: "Uyghur" },
  { code: "uz", name: "Uzbek" },
  { code: "vi", name: "Vietnamese — Tiếng Việt" },
  { code: "cy", name: "Welsh" },
  { code: "xh", name: "Xhosa" },
  { code: "yi", name: "Yiddish" },
  { code: "yo", name: "Yoruba" },
  { code: "zu", name: "Zulu" },
];

declare global {
  interface Window {
    googleTranslateElementInit?: () => void;
    google?: any;
  }
}

const SCRIPT_ID = "google-translate-script";

function readGoogtransCookie(): string {
  if (typeof document === "undefined") return "en";
  const match = document.cookie.match(/(?:^|;\s*)googtrans=([^;]+)/);
  if (!match) return "en";
  const parts = decodeURIComponent(match[1]).split("/");
  return parts[2] || "en";
}

function setGoogtransCookie(lang: string) {
  const value = `/en/${lang}`;
  // Set for the current host and parent domain so it survives subdomains.
  const host = window.location.hostname;
  const expiry = "; max-age=31536000; path=/";
  document.cookie = `googtrans=${value}${expiry}`;
  document.cookie = `googtrans=${value}${expiry}; domain=${host}`;
  const parent = host.split(".").slice(-2).join(".");
  if (parent !== host) {
    document.cookie = `googtrans=${value}${expiry}; domain=.${parent}`;
  }
}

export function LanguageSelector() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [current, setCurrent] = useState("en");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setCurrent(readGoogtransCookie());

    if (document.getElementById(SCRIPT_ID)) return;

    window.googleTranslateElementInit = () => {
      if (window.google?.translate?.TranslateElement) {
        // eslint-disable-next-line new-cap
        new window.google.translate.TranslateElement(
          { pageLanguage: "en", autoDisplay: false },
          "google_translate_element",
        );
      }
    };

    const script = document.createElement("script");
    script.id = SCRIPT_ID;
    script.src =
      "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
    script.async = true;
    document.body.appendChild(script);
  }, []);

  useEffect(() => {
    if (open) {
      setQuery("");
      const t = setTimeout(() => inputRef.current?.focus(), 50);
      return () => clearTimeout(t);
    }
  }, [open]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return LANGUAGES;
    return LANGUAGES.filter((l) => l.name.toLowerCase().includes(q));
  }, [query]);

  const currentName =
    LANGUAGES.find((l) => l.code === current)?.name.split(" — ")[0] ?? "English";

  function selectLanguage(code: string) {
    setGoogtransCookie(code);
    setCurrent(code);
    setOpen(false);
    // Reload so the Google Translate widget re-applies from the cookie.
    window.location.reload();
  }

  return (
    <>
      {/* Hidden Google Translate mount point */}
      <div id="google_translate_element" className="sr-only" aria-hidden="true" />

      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Change language"
        translate="no"
        className="notranslate fixed right-4 top-[max(1rem,env(safe-area-inset-top))] z-50 inline-flex items-center gap-1.5 rounded-full border border-border bg-popover/90 px-3 py-1.5 text-xs font-medium text-foreground shadow-md backdrop-blur transition-colors hover:bg-accent"
      >
        <Globe className="h-4 w-4 text-primary" />
        <span className="max-w-[7rem] truncate">{currentName}</span>
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[60] flex items-start justify-center bg-black/60 px-4 pt-[max(3rem,env(safe-area-inset-top))]"
          onClick={() => setOpen(false)}
        >
          <div
            className="notranslate flex max-h-[80vh] w-full max-w-md flex-col overflow-hidden rounded-2xl border border-border bg-popover shadow-xl"
            translate="no"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <h2 className="text-sm font-semibold text-foreground">Choose language</h2>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close"
                className="rounded-md p-1 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="border-b border-border px-3 py-2">
              <div className="flex items-center gap-2 rounded-lg bg-muted px-2.5 py-1.5">
                <Search className="h-4 w-4 text-muted-foreground" />
                <input
                  ref={inputRef}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search 100+ languages…"
                  className="w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
                />
              </div>
            </div>

            <ul className="flex-1 overflow-y-auto py-1">
              {filtered.map((l) => (
                <li key={l.code}>
                  <button
                    type="button"
                    onClick={() => selectLanguage(l.code)}
                    className="flex w-full items-center justify-between px-4 py-2.5 text-left text-sm text-foreground transition-colors hover:bg-accent"
                  >
                    <span>{l.name}</span>
                    {l.code === current && <Check className="h-4 w-4 text-primary" />}
                  </button>
                </li>
              ))}
              {filtered.length === 0 && (
                <li className="px-4 py-6 text-center text-sm text-muted-foreground">
                  No languages found
                </li>
              )}
            </ul>
          </div>
        </div>
      )}
    </>
  );
}