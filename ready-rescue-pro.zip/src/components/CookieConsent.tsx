import { useEffect, useState } from "react";
import { Cookie, X, Check } from "lucide-react";
import { getStoredAck, saveAck } from "../lib/permissions";

export function CookieConsent() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const ack = getStoredAck();
    if (!ack.cookie) {
      setOpen(true);
    }
  }, []);

  const accept = () => {
    saveAck({ cookie: true });
    setOpen(false);
  };

  const decline = () => {
    saveAck({ cookie: true });
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-[55] border-t border-border bg-popover/95 p-4 backdrop-blur">
      <div className="mx-auto flex max-w-md flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary">
            <Cookie className="h-5 w-5" />
          </span>
          <div>
            <p className="text-sm font-semibold text-foreground">Privacy & cookies</p>
            <p className="text-xs text-muted-foreground">
              We only store emergency data locally on your device. Tap Accept to continue, or Decline
              to use the app without analytics.
            </p>
          </div>
        </div>
        <div className="flex shrink-0 gap-2">
          <button
            onClick={decline}
            className="rounded-xl border border-border bg-card px-3 py-2 text-xs font-semibold text-foreground"
          >
            <span className="flex items-center gap-1">
              <X className="h-3.5 w-3.5" /> Decline
            </span>
          </button>
          <button
            onClick={accept}
            className="rounded-xl bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground"
          >
            <span className="flex items-center gap-1">
              <Check className="h-3.5 w-3.5" /> Accept
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
