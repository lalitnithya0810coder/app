import type { ReactNode } from "react";
import { BottomNav } from "./BottomNav";

interface AppShellProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
  /** Hide the page header (e.g. the home/SOS screen has its own). */
  bare?: boolean;
}

export function AppShell({ title, subtitle, children, bare }: AppShellProps) {
  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-md px-5 pb-28 pt-[max(1.25rem,env(safe-area-inset-top))]">
        {!bare && (
          <header className="mb-5">
            <h1 className="text-2xl font-bold text-foreground">{title}</h1>
            {subtitle && (
              <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
            )}
          </header>
        )}
        {children}
      </div>
      <BottomNav />
    </div>
  );
}