import { useEffect, useState } from "react";
import { MapPin, Bell, Camera, Mic, X, Check, Shield } from "lucide-react";
import { usePermissions, type PermissionName, saveAck, getStoredAck } from "../lib/permissions";

const items: { name: PermissionName; label: string; description: string; icon: typeof MapPin }[] = [
  {
    name: "geolocation",
    label: "Location",
    description: "Needed to share your GPS position during an SOS.",
    icon: MapPin,
  },
  {
    name: "notifications",
    label: "Notifications",
    description: "Used for safety alerts and check-in reminders.",
    icon: Bell,
  },
  {
    name: "camera",
    label: "Camera",
    description: "Record video evidence during emergencies.",
    icon: Camera,
  },
  {
    name: "microphone",
    label: "Microphone",
    description: "Capture audio evidence during emergencies.",
    icon: Mic,
  },
];

export function PermissionsPrompt() {
  const { statuses, request } = usePermissions();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const ack = getStoredAck();
    if (!ack.permissions) {
      setOpen(true);
    }
  }, []);

  const askAll = async () => {
    for (const item of items) {
      await request(item.name);
    }
    saveAck({ permissions: true });
    setOpen(false);
  };

  const askItem = async (name: PermissionName) => {
    await request(name);
  };

  const skip = () => {
    saveAck({ permissions: true });
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/70 p-0 sm:items-center sm:p-4">
      <div className="w-full max-w-md rounded-t-3xl border border-border bg-popover p-5 shadow-xl sm:rounded-3xl">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary/15 text-primary">
              <Shield className="h-5 w-5" />
            </span>
            <h2 className="text-lg font-bold text-foreground">Allow permissions</h2>
          </div>
          <button onClick={skip} className="text-muted-foreground" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </div>

        <p className="mb-4 text-sm text-muted-foreground">
          Guardian works best with these permissions. You can change them anytime in your browser settings.
        </p>

        <ul className="mb-5 space-y-2.5">
          {items.map((item) => {
            const Icon = item.icon;
            const state = statuses[item.name];
            const granted = state === "granted";
            const denied = state === "denied";
            return (
              <li
                key={item.name}
                className="flex items-center gap-3 rounded-xl border border-border bg-card p-3"
              >
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
                  <Icon className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-foreground">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.description}</p>
                </div>
                <button
                  onClick={() => askItem(item.name)}
                  disabled={granted}
                  className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-semibold ${
                    granted
                      ? "bg-safe/15 text-safe"
                      : denied
                        ? "bg-primary/15 text-primary"
                        : "bg-primary text-primary-foreground"
                  }`}
                >
                  {granted ? (
                    <span className="flex items-center gap-1">
                      <Check className="h-3.5 w-3.5" /> Allowed
                    </span>
                  ) : denied ? (
                    "Retry"
                  ) : (
                    "Allow"
                  )}
                </button>
              </li>
            );
          })}
        </ul>

        <div className="flex gap-3">
          <button
            onClick={skip}
            className="flex-1 rounded-2xl border border-border bg-card px-4 py-3 text-sm font-semibold text-foreground"
          >
            Not now
          </button>
          <button
            onClick={askAll}
            className="flex-1 rounded-2xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground"
          >
            Allow all
          </button>
        </div>
      </div>
    </div>
  );
}
