import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  Siren,
  Flashlight,
  ShieldCheck,
  Phone,
  MapPin,
  Share2,
  Copy,
  Check,
  ChevronRight,
  MessageSquare,
  WifiOff,
} from "lucide-react";
import { toast } from "sonner";
import { BottomNav } from "../components/BottomNav";
import { FlashlightOverlay } from "../components/FlashlightOverlay";
import { useLocalStorage } from "../lib/use-local-storage";
import { startSiren, stopSiren } from "../lib/siren";
import { getCurrentLocation, mapsLink, type Coords } from "../lib/location";
import { useOnlineStatus } from "../lib/use-online-status";
import { sendSmsFallback, buildSosMessage } from "../lib/sms";
import { emptyMedicalProfile, type Contact, type AlertEvent, type MedicalProfile } from "../lib/types";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Guardian — One-Tap SOS" },
      {
        name: "description",
        content:
          "Trigger an instant SOS, sound the panic siren, share your live location and alert your emergency contacts.",
      },
      { property: "og:title", content: "Guardian — One-Tap SOS" },
      {
        property: "og:description",
        content: "Instant SOS, panic siren, live location sharing and emergency contacts.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  const [contacts] = useLocalStorage<Contact[]>("guardian.contacts", []);
  const [, setHistory] = useLocalStorage<AlertEvent[]>("guardian.history", []);
  const [medical] = useLocalStorage<MedicalProfile>("guardian.medical", emptyMedicalProfile);
  const online = useOnlineStatus();

  const [countdown, setCountdown] = useState<number | null>(null);
  const [active, setActive] = useState(false);
  const [coords, setCoords] = useState<Coords | null>(null);
  const [sirenOn, setSirenOn] = useState(false);
  const [flashlight, setFlashlight] = useState(false);
  const [copied, setCopied] = useState(false);
  const timer = useRef<number | null>(null);

  const logEvent = (e: Omit<AlertEvent, "id" | "timestamp">) =>
    setHistory((prev) =>
      [{ ...e, id: crypto.randomUUID(), timestamp: Date.now() }, ...prev].slice(0, 50),
    );

  /**
   * Hand off to the device's native SMS app. This sends over the cellular
   * network, so emergency contacts are still notified with no internet.
   */
  const sendSms = (loc?: Coords | null) => {
    if (contacts.length === 0) {
      toast.error("Add emergency contacts to send SMS alerts");
      return false;
    }
    const message = buildSosMessage({
      name: medical.fullName,
      mapsUrl: loc ? mapsLink(loc.lat, loc.lng) : undefined,
    });
    const ok = sendSmsFallback(contacts, message);
    if (ok) toast.success("Opening SMS to your emergency contacts…");
    return ok;
  };

  const activate = async () => {
    setActive(true);
    setSirenOn(true);
    startSiren();
    if (online) {
      toast.error(
        contacts.length
          ? `SOS sent to ${contacts.length} emergency contact${contacts.length > 1 ? "s" : ""}`
          : "SOS activated — add contacts to notify them automatically",
      );
    } else {
      toast.warning("No internet — sending SOS by SMS instead");
    }
    let loc: Coords | null = null;
    try {
      loc = await getCurrentLocation();
      setCoords(loc);
      logEvent({ type: "sos", lat: loc.lat, lng: loc.lng, accuracy: loc.accuracy });
    } catch {
      logEvent({ type: "sos" });
      toast.warning("Couldn't get your location — alert sent without it");
    }
    // Offline: fall back to native SMS once we've resolved the location.
    if (!online) sendSms(loc);
  };

  const startCountdown = () => {
    if (active) return;
    setCountdown(3);
  };

  useEffect(() => {
    if (countdown === null) return;
    if (countdown <= 0) {
      setCountdown(null);
      void activate();
      return;
    }
    timer.current = window.setTimeout(() => setCountdown((c) => (c ?? 1) - 1), 1000);
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [countdown]);

  const cancel = () => {
    setCountdown(null);
    if (timer.current) window.clearTimeout(timer.current);
  };

  const deactivate = () => {
    setActive(false);
    setSirenOn(false);
    stopSiren();
    setCoords(null);
  };

  const toggleSiren = () => {
    if (sirenOn) {
      stopSiren();
      setSirenOn(false);
    } else {
      startSiren();
      setSirenOn(true);
    }
  };

  const checkInSafe = () => {
    logEvent({ type: "safe" });
    toast.success("You're marked safe. Contacts have been notified.");
  };

  const shareLocation = async () => {
    const link = coords ? mapsLink(coords.lat, coords.lng) : undefined;
    if (!link) return;
    const text = `Emergency! This is my live location: ${link}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: "My location", text, url: link });
        return;
      } catch {
        /* fall through to copy */
      }
    }
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("Location link copied to clipboard");
  };

  useEffect(() => () => stopSiren(), []);

  return (
    <div className="min-h-screen bg-background">
      {flashlight && <FlashlightOverlay onClose={() => setFlashlight(false)} />}
      <div className="mx-auto max-w-md px-5 pb-28 pt-[max(1.5rem,env(safe-area-inset-top))]">
        <header className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary/15 text-primary">
              <ShieldCheck className="h-5 w-5" />
            </span>
            <div>
              <p className="text-base font-bold leading-none text-foreground">Guardian</p>
              <p className="text-xs text-muted-foreground">Emergency help, one tap away</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {!online && (
              <span className="flex items-center gap-1 rounded-full bg-warning/15 px-2.5 py-1 text-[11px] font-semibold text-warning">
                <WifiOff className="h-3.5 w-3.5" /> Offline · SMS
              </span>
            )}
            <Link
              to="/medical"
              className="rounded-full border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground"
            >
              Profile
            </Link>
          </div>
        </header>

        {/* SOS BUTTON */}
        <div className="relative flex flex-col items-center py-6">
          <p className="mb-6 text-center text-sm text-muted-foreground">
            {active
              ? "SOS is active. Help is on the way."
              : countdown !== null
                ? "Sending SOS… tap to cancel"
                : "Press and hold area below in an emergency"}
          </p>

          <button
            onClick={countdown !== null ? cancel : active ? deactivate : startCountdown}
            className={`grid h-60 w-60 place-items-center rounded-full text-primary-foreground transition-transform active:scale-95 ${
              active || countdown !== null
                ? "bg-primary"
                : "bg-primary sos-glow"
            }`}
          >
            <span className="flex flex-col items-center">
              <span className="text-6xl font-bold tracking-tight">
                {countdown !== null ? countdown : "SOS"}
              </span>
              <span className="mt-1 text-sm font-medium opacity-90">
                {active ? "Tap to stop" : countdown !== null ? "Cancel" : "Tap to send"}
              </span>
            </span>
          </button>
        </div>

        {/* ACTIVE PANEL */}
        {active && (
          <div className="mb-6 rounded-2xl border border-primary/40 bg-primary/10 p-4">
            <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
              <span className="relative flex h-2.5 w-2.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-primary" />
              </span>
              Live emergency active
            </div>
            <p className="mt-2 flex items-center gap-1.5 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4 shrink-0" />
              {coords
                ? `Location locked · ±${Math.round(coords.accuracy)}m accuracy`
                : "Locating you…"}
            </p>
            {coords && (
              <button
                onClick={shareLocation}
                className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground"
              >
                {copied ? <Check className="h-4 w-4" /> : <Share2 className="h-4 w-4" />}
                Share live location
              </button>
            )}
            <button
              onClick={() => sendSms(coords)}
              className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-semibold text-foreground"
            >
              <MessageSquare className="h-4 w-4" />
              {online ? "Send SMS alert too" : "Resend SMS alert"}
            </button>
            {!online && (
              <p className="mt-2 text-center text-xs text-muted-foreground">
                You're offline — alerts are delivered via your phone's SMS app.
              </p>
            )}
          </div>
        )}

        {/* QUICK ACTIONS */}
        <div className="mb-6 grid grid-cols-4 gap-3">
          <QuickAction
            label={sirenOn ? "Siren On" : "Siren"}
            icon={Siren}
            active={sirenOn}
            onClick={toggleSiren}
          />
          <QuickAction label="Flashlight" icon={Flashlight} onClick={() => setFlashlight(true)} />
          <QuickAction label="I'm Safe" icon={ShieldCheck} tone="safe" onClick={checkInSafe} />
          <QuickAction
            label="Call 112"
            icon={Phone}
            onClick={() => (window.location.href = "tel:112")}
          />
        </div>

        {/* EMERGENCY SERVICES SHORTCUT */}
        <Link
          to="/services"
          className="mb-4 flex items-center justify-between rounded-2xl border border-border bg-card p-4"
        >
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/15 text-primary">
              <Phone className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-semibold text-foreground">Emergency Services</p>
              <p className="text-xs text-muted-foreground">Police · Ambulance · Fire</p>
            </div>
          </div>
          <ChevronRight className="h-5 w-5 text-muted-foreground" />
        </Link>

        <Link
          to="/safety"
          className="flex items-center justify-between rounded-2xl border border-border bg-card p-4"
        >
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-info/15 text-info">
              <MapPin className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-semibold text-foreground">Safety & Location</p>
              <p className="text-xs text-muted-foreground">Nearby help · location history</p>
            </div>
          </div>
          <ChevronRight className="h-5 w-5 text-muted-foreground" />
        </Link>
      </div>
      <BottomNav />
    </div>
  );
}

function QuickAction({
  label,
  icon: Icon,
  onClick,
  active,
  tone,
}: {
  label: string;
  icon: typeof Siren;
  onClick: () => void;
  active?: boolean;
  tone?: "safe";
}) {
  const color = tone === "safe" ? "text-safe" : active ? "text-primary" : "text-foreground";
  const ring = active ? "border-primary bg-primary/10" : "border-border bg-card";
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1.5 rounded-2xl border ${ring} px-2 py-3 transition-colors`}
    >
      <Icon className={`h-6 w-6 ${color}`} />
      <span className="text-[11px] font-medium text-muted-foreground">{label}</span>
    </button>
  );
}
