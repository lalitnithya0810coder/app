import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronDown, BookOpen } from "lucide-react";
import { AppShell } from "../components/AppShell";
import { firstAidGuides } from "../lib/data";

export const Route = createFileRoute("/guides")({
  head: () => ({
    meta: [
      { title: "First Aid Guides — Guardian" },
      {
        name: "description",
        content: "Step-by-step first-aid instructions for CPR, choking, bleeding, burns, seizures and stroke.",
      },
      { property: "og:title", content: "First Aid Guides — Guardian" },
      { property: "og:description", content: "Quick first-aid steps for common emergencies." },
    ],
  }),
  component: GuidesPage,
});

function GuidesPage() {
  const [open, setOpen] = useState<string | null>("cpr");

  return (
    <AppShell title="First Aid Guides" subtitle="Calm, step-by-step help for common emergencies.">
      <div className="mb-5 flex items-center gap-3 rounded-2xl border border-info/30 bg-info/10 p-4">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-info/20 text-info">
          <BookOpen className="h-5 w-5" />
        </span>
        <p className="text-sm text-muted-foreground">
          These are general guides. Always call emergency services first if you can.
        </p>
      </div>

      <div className="space-y-3">
        {firstAidGuides.map((g) => {
          const isOpen = open === g.id;
          return (
            <div key={g.id} className="overflow-hidden rounded-2xl border border-border bg-card">
              <button
                onClick={() => setOpen(isOpen ? null : g.id)}
                className="flex w-full items-center justify-between gap-3 p-4 text-left"
              >
                <div>
                  <p className="text-sm font-semibold text-foreground">{g.title}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">{g.summary}</p>
                </div>
                <ChevronDown
                  className={`h-5 w-5 shrink-0 text-muted-foreground transition-transform ${isOpen ? "rotate-180" : ""}`}
                />
              </button>
              {isOpen && (
                <ol className="space-y-2.5 border-t border-border px-4 pb-4 pt-3">
                  {g.steps.map((step, i) => (
                    <li key={i} className="flex gap-3 text-sm text-foreground">
                      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-primary/15 text-xs font-bold text-primary">
                        {i + 1}
                      </span>
                      <span className="pt-0.5 text-muted-foreground">{step}</span>
                    </li>
                  ))}
                </ol>
              )}
            </div>
          );
        })}
      </div>
    </AppShell>
  );
}