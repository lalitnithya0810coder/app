import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { HeartPulse, Save, Droplet } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "../components/AppShell";
import { useLocalStorage } from "../lib/use-local-storage";
import { emptyMedicalProfile, type MedicalProfile } from "../lib/types";

export const Route = createFileRoute("/medical")({
  head: () => ({
    meta: [
      { title: "Medical Profile — Guardian" },
      {
        name: "description",
        content: "Store blood group, allergies, medications and conditions so first responders have what they need.",
      },
      { property: "og:title", content: "Medical Profile — Guardian" },
      { property: "og:description", content: "Vital medical info for first responders." },
    ],
  }),
  component: MedicalPage,
});

function MedicalPage() {
  const [saved, setSaved] = useLocalStorage<MedicalProfile>("guardian.medical", emptyMedicalProfile);
  const [form, setForm] = useState<MedicalProfile>(saved);

  // useLocalStorage hydrates from localStorage asynchronously after mount, so
  // sync the form with the stored profile once (and only before the user edits).
  const hydrated = useRef(false);
  useEffect(() => {
    if (!hydrated.current) {
      hydrated.current = true;
      setForm(saved);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [saved]);

  const set = <K extends keyof MedicalProfile>(key: K, value: MedicalProfile[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const save = () => {
    setSaved(form);
    toast.success("Medical profile saved");
  };

  const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

  return (
    <AppShell title="Medical Profile" subtitle="Shared with responders during an emergency.">
      <div className="mb-5 flex items-center gap-3 rounded-2xl border border-primary/30 bg-primary/10 p-4">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/20 text-primary">
          <HeartPulse className="h-5 w-5" />
        </span>
        <p className="text-sm text-muted-foreground">
          Keep this accurate. It could save your life when you can't speak for yourself.
        </p>
      </div>

      <div className="space-y-4">
        <TextField label="Full name" value={form.fullName} onChange={(v) => set("fullName", v)} placeholder="Your name" />
        <TextField label="Date of birth" value={form.dob} onChange={(v) => set("dob", v)} type="date" />

        <div>
          <span className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <Droplet className="h-3.5 w-3.5" /> Blood group
          </span>
          <div className="grid grid-cols-4 gap-2">
            {bloodGroups.map((bg) => (
              <button
                key={bg}
                onClick={() => set("bloodGroup", bg)}
                className={`rounded-xl border py-2.5 text-sm font-semibold transition-colors ${
                  form.bloodGroup === bg
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-card text-foreground"
                }`}
              >
                {bg}
              </button>
            ))}
          </div>
        </div>

        <TextArea label="Allergies" value={form.allergies} onChange={(v) => set("allergies", v)} placeholder="Penicillin, peanuts…" />
        <TextArea label="Current medications" value={form.medications} onChange={(v) => set("medications", v)} placeholder="Name & dosage" />
        <TextArea label="Medical conditions" value={form.conditions} onChange={(v) => set("conditions", v)} placeholder="Asthma, diabetes…" />
        <TextArea label="Other notes" value={form.notes} onChange={(v) => set("notes", v)} placeholder="Anything responders should know" />

        <label className="flex items-center justify-between rounded-2xl border border-border bg-card p-4">
          <span className="text-sm font-medium text-foreground">Registered organ donor</span>
          <button
            onClick={() => set("organDonor", !form.organDonor)}
            className={`relative h-6 w-11 rounded-full transition-colors ${form.organDonor ? "bg-safe" : "bg-muted"}`}
            aria-pressed={form.organDonor}
          >
            <span
              className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform ${
                form.organDonor ? "translate-x-[22px]" : "translate-x-0.5"
              }`}
            />
          </button>
        </label>
      </div>

      <button
        onClick={save}
        className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-primary px-4 py-3.5 text-sm font-semibold text-primary-foreground"
      >
        <Save className="h-5 w-5" />
        Save Medical Profile
      </button>
    </AppShell>
  );
}

function TextField({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-muted-foreground">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-xl border border-input bg-background px-3.5 py-2.5 text-sm text-foreground outline-none placeholder:text-muted-foreground/60 focus:border-ring"
      />
    </label>
  );
}

function TextArea({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-muted-foreground">{label}</span>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={2}
        className="w-full resize-none rounded-xl border border-input bg-background px-3.5 py-2.5 text-sm text-foreground outline-none placeholder:text-muted-foreground/60 focus:border-ring"
      />
    </label>
  );
}