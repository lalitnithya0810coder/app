import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Trash2, Phone, MessageSquare, UserPlus, X } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "../components/AppShell";
import { useLocalStorage } from "../lib/use-local-storage";
import type { Contact } from "../lib/types";

export const Route = createFileRoute("/contacts")({
  head: () => ({
    meta: [
      { title: "Emergency Contacts — Guardian" },
      {
        name: "description",
        content: "Store the family, friends and guardians who get alerted the moment you trigger an SOS.",
      },
      { property: "og:title", content: "Emergency Contacts — Guardian" },
      { property: "og:description", content: "People who get alerted when you trigger an SOS." },
    ],
  }),
  component: ContactsPage,
});

function ContactsPage() {
  const [contacts, setContacts] = useLocalStorage<Contact[]>("guardian.contacts", []);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", relation: "" });

  const add = () => {
    if (!form.name.trim() || !form.phone.trim()) {
      toast.error("Name and phone are required");
      return;
    }
    setContacts((prev) => [
      ...prev,
      { id: crypto.randomUUID(), name: form.name.trim(), phone: form.phone.trim(), relation: form.relation.trim() || "Contact" },
    ]);
    setForm({ name: "", phone: "", relation: "" });
    setOpen(false);
    toast.success("Emergency contact added");
  };

  const remove = (id: string) => {
    setContacts((prev) => prev.filter((c) => c.id !== id));
    toast.success("Contact removed");
  };

  return (
    <AppShell title="Emergency Contacts" subtitle="These people are alerted when you send an SOS.">
      {contacts.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-card/50 p-8 text-center">
          <span className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-full bg-primary/15 text-primary">
            <UserPlus className="h-6 w-6" />
          </span>
          <p className="text-sm font-medium text-foreground">No contacts yet</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Add trusted people who should be notified in an emergency.
          </p>
        </div>
      ) : (
        <ul className="space-y-3">
          {contacts.map((c) => (
            <li key={c.id} className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3.5">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-primary/15 text-sm font-semibold text-primary">
                {c.name.slice(0, 2).toUpperCase()}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-foreground">{c.name}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {c.relation} · {c.phone}
                </p>
              </div>
              <a
                href={`tel:${c.phone}`}
                className="grid h-9 w-9 place-items-center rounded-full bg-safe/15 text-safe"
                aria-label={`Call ${c.name}`}
              >
                <Phone className="h-4 w-4" />
              </a>
              <a
                href={`sms:${c.phone}`}
                className="grid h-9 w-9 place-items-center rounded-full bg-info/15 text-info"
                aria-label={`Message ${c.name}`}
              >
                <MessageSquare className="h-4 w-4" />
              </a>
              <button
                onClick={() => remove(c.id)}
                className="grid h-9 w-9 place-items-center rounded-full bg-muted text-muted-foreground"
                aria-label={`Remove ${c.name}`}
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}

      <button
        onClick={() => setOpen(true)}
        className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-primary px-4 py-3.5 text-sm font-semibold text-primary-foreground"
      >
        <Plus className="h-5 w-5" />
        Add Emergency Contact
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 sm:items-center sm:p-4">
          <div className="w-full max-w-md rounded-t-3xl border border-border bg-popover p-5 sm:rounded-3xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-bold text-foreground">New Contact</h2>
              <button onClick={() => setOpen(false)} className="text-muted-foreground">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="space-y-3">
              <Field label="Full name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} placeholder="Jane Doe" />
              <Field label="Phone number" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} placeholder="+1 555 0100" type="tel" />
              <Field label="Relationship" value={form.relation} onChange={(v) => setForm({ ...form, relation: v })} placeholder="Sister, Friend…" />
            </div>
            <button
              onClick={add}
              className="mt-5 w-full rounded-2xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground"
            >
              Save Contact
            </button>
          </div>
        </div>
      )}
    </AppShell>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-muted-foreground">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-xl border border-input bg-background px-3.5 py-2.5 text-sm text-foreground outline-none placeholder:text-muted-foreground/60 focus:border-ring"
      />
    </label>
  );
}