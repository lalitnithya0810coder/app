import { createFileRoute } from "@tanstack/react-router";
import {
  Siren,
  Shield,
  Ambulance,
  Flame,
  Skull,
  HeartPulse,
  Phone,
  Baby,
  ShieldUser,
  AlertTriangle,
  Search,
  Pill,
  CloudLightning,
} from "lucide-react";
import { AppShell } from "../components/AppShell";
import { emergencyServices } from "../lib/data";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Emergency Services — Guardian" },
      {
        name: "description",
        content: "Quick-dial police, ambulance, fire department, poison control and crisis lines.",
      },
      { property: "og:title", content: "Emergency Services — Guardian" },
      { property: "og:description", content: "Quick-dial emergency service numbers." },
    ],
  }),
  component: ServicesPage,
});

const icons = { siren: Siren, shield: Shield, ambulance: Ambulance, flame: Flame, skull: Skull, "heart-pulse": HeartPulse, baby: Baby, "shield-user": ShieldUser, "alert-triangle": AlertTriangle, search: Search, pill: Pill, "cloud-lightning": CloudLightning } as const;

function ServicesPage() {
  return (
    <AppShell title="Emergency Services" subtitle="Tap any service to call instantly.">
      <ul className="space-y-3">
        {emergencyServices.map((s) => {
          const Icon = icons[s.icon as keyof typeof icons] ?? Phone;
          return (
            <li key={s.label}>
              <a
                href={`tel:${s.number}`}
                className="flex items-center gap-3 rounded-2xl border border-border bg-card p-4 transition-colors active:bg-accent"
              >
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary">
                  <Icon className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-foreground">{s.label}</p>
                  <p className="text-xs text-muted-foreground">Dial {s.number}</p>
                </div>
                <span className="grid h-10 w-10 place-items-center rounded-full bg-safe text-safe-foreground">
                  <Phone className="h-5 w-5" />
                </span>
              </a>
            </li>
          );
        })}
      </ul>
      <p className="mt-5 text-center text-xs text-muted-foreground">
        Default numbers shown. Verify the correct numbers for your country.
      </p>
    </AppShell>
  );
}