import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  MapPin,
  Share2,
  Hospital,
  Shield,
  Home,
  Pill,
  Navigation,
  History,
  ShieldCheck,
} from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "../components/AppShell";
import { useLocalStorage } from "../lib/use-local-storage";
import { getCurrentLocation, mapsLink, type Coords } from "../lib/location";
import { nearbyHelpCenters, type HelpCenter } from "../lib/data";
import type { AlertEvent } from "../lib/types";

export const Route = createFileRoute("/safety")({
  head: () => ({
    meta: [
      { title: "Safety & Location — Guardian" },
      {
        name: "description",
        content: "Share your live GPS location, view location history and find nearby hospitals, police and shelters.",
      },
      { property: "og:title", content: "Safety & Location — Guardian" },
      { property: "og:description", content: "Live location sharing and nearby help centers." },
    ],
  }),
  component: SafetyPage,
});

const centerIcons: Record<HelpCenter["type"], typeof Hospital> = {
  Hospital,
  Police: Shield,
  Shelter: Home,
  Pharmacy: Pill,
};

function SafetyPage() {
  const [history] = useLocalStorage<AlertEvent[]>("guardian.history", []);
  const [coords, setCoords] = useState<Coords | null>(null);
  const [loading, setLoading] = useState(false);

  const locate = async () => {
    setLoading(true);
    try {
      const loc = await getCurrentLocation();
      setCoords(loc);
      toast.success("Location found");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't get location");
    } finally {
      setLoading(false);
    }
  };

  const share = async () => {
    if (!coords) return;
    const link = mapsLink(coords.lat, coords.lng);
    const text = `My current location: ${link}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: "My location", text, url: link });
        return;
      } catch {
        /* fall through */
      }
    }
    await navigator.clipboard.writeText(text);
    toast.success("Location link copied");
  };

  return (
    <AppShell title="Safety & Location" subtitle="Share where you are and find help nearby.">
      {/* Live location */}
      <div className="mb-6 rounded-2xl border border-border bg-card p-4">
        <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
          <Navigation className="h-4 w-4 text-info" /> Live Location
        </div>
        {coords ? (
          <p className="mt-2 text-sm text-muted-foreground">
            {coords.lat.toFixed(5)}, {coords.lng.toFixed(5)} · ±{Math.round(coords.accuracy)}m
          </p>
        ) : (
          <p className="mt-2 text-sm text-muted-foreground">Get your current GPS position to share it.</p>
        )}
        <div className="mt-3 flex gap-2">
          <button
            onClick={locate}
            disabled={loading}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-info px-4 py-2.5 text-sm font-semibold text-info-foreground disabled:opacity-60"
          >
            <MapPin className="h-4 w-4" />
            {loading ? "Locating…" : "Get Location"}
          </button>
          {coords && (
            <button
              onClick={share}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground"
            >
              <Share2 className="h-4 w-4" /> Share
            </button>
          )}
        </div>
      </div>

      {/* Nearby help */}
      <h2 className="mb-3 text-sm font-semibold text-foreground">Nearby Help Centers</h2>
      <ul className="mb-6 space-y-3">
        {nearbyHelpCenters.map((c) => {
          const Icon = centerIcons[c.type];
          return (
            <li key={c.name}>
              <a
                href={`https://www.google.com/maps/search/${encodeURIComponent(c.type + " near me")}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3.5"
              >
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-safe/15 text-safe">
                  <Icon className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-foreground">{c.name}</p>
                  <p className="truncate text-xs text-muted-foreground">{c.detail}</p>
                </div>
                <span className="rounded-full bg-muted px-2.5 py-1 text-[10px] font-medium text-muted-foreground">
                  {c.type}
                </span>
              </a>
            </li>
          );
        })}
      </ul>

      {/* Location history */}
      <h2 className="mb-3 flex items-center gap-1.5 text-sm font-semibold text-foreground">
        <History className="h-4 w-4" /> Recent Activity
      </h2>
      {history.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-border bg-card/50 p-5 text-center text-sm text-muted-foreground">
          No activity yet. SOS alerts and check-ins will appear here.
        </p>
      ) : (
        <ul className="space-y-2.5">
          {history.map((h) => (
            <li key={h.id} className="flex items-center gap-3 rounded-xl border border-border bg-card p-3">
              <span
                className={`grid h-9 w-9 shrink-0 place-items-center rounded-full ${
                  h.type === "sos" ? "bg-primary/15 text-primary" : "bg-safe/15 text-safe"
                }`}
              >
                {h.type === "sos" ? <MapPin className="h-4 w-4" /> : <ShieldCheck className="h-4 w-4" />}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-foreground">
                  {h.type === "sos" ? "SOS triggered" : "Marked safe"}
                </p>
                <p className="text-xs text-muted-foreground">
                  {new Date(h.timestamp).toLocaleString()}
                </p>
              </div>
              {h.lat != null && h.lng != null && (
                <a
                  href={mapsLink(h.lat, h.lng)}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs font-medium text-info"
                >
                  Map
                </a>
              )}
            </li>
          ))}
        </ul>
      )}
    </AppShell>
  );
}