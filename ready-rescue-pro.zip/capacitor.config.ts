import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "app.lovable.readyrescuepro",
  appName: "Ready Rescue Pro",
  // Your app is server-rendered (TanStack Start), so the native shell loads
  // the published web app directly. Update this URL if your published domain
  // changes (Project settings > Domains).
  webDir: "dist",
  server: {
    url: "https://ready-rescue-pro.lovable.app",
    cleartext: false,
  },
  android: {
    backgroundColor: "#1a1626",
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      backgroundColor: "#1a1626",
      showSpinner: false,
    },
    StatusBar: {
      backgroundColor: "#1a1626",
      style: "DARK",
    },
  },
};

export default config;