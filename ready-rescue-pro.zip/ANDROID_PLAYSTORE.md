# Publishing Ready Rescue Pro to the Google Play Store

Your app is now Capacitor-ready. Capacitor wraps your published web app inside a
native Android shell, which produces an installable Android App Bundle (`.aab`)
you can upload to the Play Store.

> Capacitor needs **Android Studio** + a JDK on your own computer. These steps
> are run locally (not inside Lovable). Export your project to GitHub or download
> the code first.

## 1. One-time setup (on your computer)

Install:

- [Node.js](https://nodejs.org/) (18+) and [Bun](https://bun.sh/) (or npm)
- [Android Studio](https://developer.android.com/studio) (includes the Android SDK)
- A Java JDK 17 (Android Studio bundles one)

Then, in the project folder:

```bash
bun install            # or: npm install
npx cap add android    # creates the native android/ project (first time only)
```

## 2. Sync your app into the native shell

Whenever you change `capacitor.config.ts` or update dependencies:

```bash
npx cap sync android
```

The native shell loads your live published site
(`https://ready-rescue-pro.lovable.app`). So any change you publish in Lovable
shows up in the app automatically — no rebuild needed for content updates.

## 3. Open the native project

```bash
npx cap open android
```

This opens Android Studio.

## 4. Set the app icon & splash

In Android Studio: right-click `app` > **New > Image Asset** to generate launcher
icons, or use [`@capacitor/assets`](https://github.com/ionic-team/capacitor-assets):

```bash
npx @capacitor/assets generate --android
```
(place a 1024x1024 `icon.png` and `splash.png` in a `resources/` folder first)

## 5. Generate a signing key (one time)

```bash
keytool -genkey -v -keystore ready-rescue.keystore \
  -alias ready-rescue -keyalg RSA -keysize 2048 -validity 10000
```

Keep this `.keystore` file and its passwords safe — you need them for every
future update.

## 6. Build the release bundle (AAB)

In Android Studio: **Build > Generate Signed Bundle / APK > Android App Bundle**,
select your keystore, and choose the **release** build. The output is:

```
android/app/release/app-release.aab
```

## 7. Upload to Google Play

1. Create a [Google Play Developer account](https://play.google.com/console) ($25 one-time).
2. **Create app** > fill the store listing (name, description, screenshots, icon).
3. Under **Production > Create new release**, upload the `.aab`.
4. Complete the required forms (content rating, data safety, privacy policy URL).
5. Submit for review.

## Notes for an emergency app

- Google reviews safety/emergency apps carefully — clearly describe in the
  listing that this is an informational personal-safety tool, not a replacement
  for calling official emergency services.
- Add a **privacy policy URL** (required because the app requests location,
  camera, and microphone permissions).
- The `appId` in `capacitor.config.ts` (`app.lovable.readyrescuepro`) is your
  permanent package name on the Play Store — change it before your first upload
  if you want your own, then it can never be changed.